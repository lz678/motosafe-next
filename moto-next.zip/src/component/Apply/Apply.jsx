import Style from './Apply.module.less'
let Apply = ()=>{
    return (
        <div className={Style.bbox}>
            <div>页面维护中！</div>
            <a href="https://beian.miit.gov.cn/" target="_blank" className={Style.id}>蜀ICP备2022027478号-1</a>
        </div>
    )
}
export default Apply